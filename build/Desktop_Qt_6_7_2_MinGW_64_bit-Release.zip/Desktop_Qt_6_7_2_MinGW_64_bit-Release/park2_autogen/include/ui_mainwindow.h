/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.7.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *action;
    QWidget *centralwidget;
    QComboBox *comboBox;
    QLineEdit *plateNumEdit;
    QPushButton *parkButton;
    QPushButton *randomButton;
    QLineEdit *filePathEditor;
    QPushButton *park_1;
    QFrame *line;
    QFrame *line_2;
    QFrame *line_3;
    QFrame *line_4;
    QPushButton *queue_1;
    QFrame *line_5;
    QFrame *line_6;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QPushButton *park_2;
    QPushButton *park_3;
    QPushButton *park_4;
    QPushButton *park_5;
    QPushButton *park_6;
    QPushButton *park_7;
    QPushButton *park_8;
    QPushButton *park_9;
    QPushButton *park_10;
    QPushButton *queue_2;
    QPushButton *queue_3;
    QPushButton *queue_4;
    QPushButton *queue_5;
    QPushButton *queue_6;
    QPushButton *queue_7;
    QPushButton *queue_8;
    QPushButton *queue_9;
    QPushButton *queue_10;
    QPushButton *out;
    QTextEdit *log;
    QMenuBar *menubar;
    QMenu *menu;
    QMenu *m;
    QMenu *menuFile;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(840, 600);
        MainWindow->setMinimumSize(QSize(840, 600));
        MainWindow->setMaximumSize(QSize(840, 600));
        QFont font;
        font.setBold(true);
        MainWindow->setFont(font);
        action = new QAction(MainWindow);
        action->setObjectName("action");
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        comboBox = new QComboBox(centralwidget);
        comboBox->setObjectName("comboBox");
        comboBox->setGeometry(QRect(9, 10, 71, 51));
        QSizePolicy sizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(comboBox->sizePolicy().hasHeightForWidth());
        comboBox->setSizePolicy(sizePolicy);
        QFont font1;
        font1.setFamilies({QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221")});
        font1.setPointSize(20);
        font1.setBold(false);
        comboBox->setFont(font1);
        comboBox->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        comboBox->setMaxVisibleItems(8);
        plateNumEdit = new QLineEdit(centralwidget);
        plateNumEdit->setObjectName("plateNumEdit");
        plateNumEdit->setGeometry(QRect(80, 10, 181, 51));
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(plateNumEdit->sizePolicy().hasHeightForWidth());
        plateNumEdit->setSizePolicy(sizePolicy1);
        QFont font2;
        font2.setFamilies({QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221")});
        font2.setPointSize(20);
        font2.setBold(false);
        font2.setKerning(true);
        plateNumEdit->setFont(font2);
#if QT_CONFIG(tooltip)
        plateNumEdit->setToolTip(QString::fromUtf8(""));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(statustip)
        plateNumEdit->setStatusTip(QString::fromUtf8(""));
#endif // QT_CONFIG(statustip)
#if QT_CONFIG(whatsthis)
        plateNumEdit->setWhatsThis(QString::fromUtf8(""));
#endif // QT_CONFIG(whatsthis)
#if QT_CONFIG(accessibility)
        plateNumEdit->setAccessibleName(QString::fromUtf8(""));
#endif // QT_CONFIG(accessibility)
#if QT_CONFIG(accessibility)
        plateNumEdit->setAccessibleDescription(QString::fromUtf8(""));
#endif // QT_CONFIG(accessibility)
        plateNumEdit->setMaxLength(6);
        plateNumEdit->setEchoMode(QLineEdit::EchoMode::Normal);
        plateNumEdit->setAlignment(Qt::AlignmentFlag::AlignCenter);
        parkButton = new QPushButton(centralwidget);
        parkButton->setObjectName("parkButton");
        parkButton->setGeometry(QRect(10, 130, 251, 51));
        QFont font3;
        font3.setFamilies({QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221")});
        font3.setPointSize(24);
        font3.setBold(false);
        parkButton->setFont(font3);
        randomButton = new QPushButton(centralwidget);
        randomButton->setObjectName("randomButton");
        randomButton->setGeometry(QRect(10, 70, 251, 51));
        randomButton->setFont(font3);
        filePathEditor = new QLineEdit(centralwidget);
        filePathEditor->setObjectName("filePathEditor");
        filePathEditor->setGeometry(QRect(10, 500, 811, 41));
        QFont font4;
        font4.setPointSize(10);
        font4.setBold(false);
        filePathEditor->setFont(font4);
        park_1 = new QPushButton(centralwidget);
        park_1->setObjectName("park_1");
        park_1->setEnabled(false);
        park_1->setGeometry(QRect(460, 10, 141, 41));
        QFont font5;
        font5.setFamilies({QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221")});
        font5.setPointSize(14);
        font5.setBold(false);
        park_1->setFont(font5);
        park_1->setText(QString::fromUtf8(""));
#if QT_CONFIG(shortcut)
        park_1->setShortcut(QString::fromUtf8(""));
#endif // QT_CONFIG(shortcut)
        park_1->setCheckable(false);
        line = new QFrame(centralwidget);
        line->setObjectName("line");
        line->setGeometry(QRect(440, 0, 20, 411));
        line->setFrameShape(QFrame::Shape::VLine);
        line->setFrameShadow(QFrame::Shadow::Sunken);
        line_2 = new QFrame(centralwidget);
        line_2->setObjectName("line_2");
        line_2->setGeometry(QRect(600, 0, 20, 411));
        line_2->setFrameShape(QFrame::Shape::VLine);
        line_2->setFrameShadow(QFrame::Shadow::Sunken);
        line_3 = new QFrame(centralwidget);
        line_3->setObjectName("line_3");
        line_3->setGeometry(QRect(610, 0, 20, 411));
        line_3->setFrameShape(QFrame::Shape::VLine);
        line_3->setFrameShadow(QFrame::Shadow::Sunken);
        line_4 = new QFrame(centralwidget);
        line_4->setObjectName("line_4");
        line_4->setGeometry(QRect(770, 0, 20, 411));
        line_4->setFrameShape(QFrame::Shape::VLine);
        line_4->setFrameShadow(QFrame::Shadow::Sunken);
        queue_1 = new QPushButton(centralwidget);
        queue_1->setObjectName("queue_1");
        queue_1->setEnabled(false);
        queue_1->setGeometry(QRect(290, 10, 141, 41));
        queue_1->setFont(font5);
        line_5 = new QFrame(centralwidget);
        line_5->setObjectName("line_5");
        line_5->setGeometry(QRect(270, 0, 20, 411));
        line_5->setFrameShape(QFrame::Shape::VLine);
        line_5->setFrameShadow(QFrame::Shadow::Sunken);
        line_6 = new QFrame(centralwidget);
        line_6->setObjectName("line_6");
        line_6->setGeometry(QRect(430, 0, 20, 411));
        line_6->setFrameShape(QFrame::Shape::VLine);
        line_6->setFrameShadow(QFrame::Shadow::Sunken);
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(320, 420, 81, 41));
        label->setFont(font1);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(480, 420, 81, 41));
        label_2->setFont(font1);
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(670, 420, 61, 41));
        label_3->setFont(font1);
        park_2 = new QPushButton(centralwidget);
        park_2->setObjectName("park_2");
        park_2->setEnabled(false);
        park_2->setGeometry(QRect(460, 50, 141, 41));
        park_2->setFont(font5);
        park_2->setText(QString::fromUtf8(""));
#if QT_CONFIG(shortcut)
        park_2->setShortcut(QString::fromUtf8(""));
#endif // QT_CONFIG(shortcut)
        park_2->setCheckable(false);
        park_3 = new QPushButton(centralwidget);
        park_3->setObjectName("park_3");
        park_3->setEnabled(false);
        park_3->setGeometry(QRect(460, 90, 141, 41));
        park_3->setFont(font5);
        park_3->setText(QString::fromUtf8(""));
#if QT_CONFIG(shortcut)
        park_3->setShortcut(QString::fromUtf8(""));
#endif // QT_CONFIG(shortcut)
        park_3->setCheckable(false);
        park_4 = new QPushButton(centralwidget);
        park_4->setObjectName("park_4");
        park_4->setEnabled(false);
        park_4->setGeometry(QRect(460, 130, 141, 41));
        park_4->setFont(font5);
        park_4->setText(QString::fromUtf8(""));
#if QT_CONFIG(shortcut)
        park_4->setShortcut(QString::fromUtf8(""));
#endif // QT_CONFIG(shortcut)
        park_4->setCheckable(false);
        park_5 = new QPushButton(centralwidget);
        park_5->setObjectName("park_5");
        park_5->setEnabled(false);
        park_5->setGeometry(QRect(460, 170, 141, 41));
        park_5->setFont(font5);
        park_5->setText(QString::fromUtf8(""));
#if QT_CONFIG(shortcut)
        park_5->setShortcut(QString::fromUtf8(""));
#endif // QT_CONFIG(shortcut)
        park_5->setCheckable(false);
        park_6 = new QPushButton(centralwidget);
        park_6->setObjectName("park_6");
        park_6->setEnabled(false);
        park_6->setGeometry(QRect(460, 210, 141, 41));
        park_6->setFont(font5);
        park_6->setText(QString::fromUtf8(""));
#if QT_CONFIG(shortcut)
        park_6->setShortcut(QString::fromUtf8(""));
#endif // QT_CONFIG(shortcut)
        park_6->setCheckable(false);
        park_7 = new QPushButton(centralwidget);
        park_7->setObjectName("park_7");
        park_7->setEnabled(false);
        park_7->setGeometry(QRect(460, 250, 141, 41));
        park_7->setFont(font5);
        park_7->setText(QString::fromUtf8(""));
#if QT_CONFIG(shortcut)
        park_7->setShortcut(QString::fromUtf8(""));
#endif // QT_CONFIG(shortcut)
        park_7->setCheckable(false);
        park_8 = new QPushButton(centralwidget);
        park_8->setObjectName("park_8");
        park_8->setEnabled(false);
        park_8->setGeometry(QRect(460, 290, 141, 41));
        park_8->setFont(font5);
        park_8->setText(QString::fromUtf8(""));
#if QT_CONFIG(shortcut)
        park_8->setShortcut(QString::fromUtf8(""));
#endif // QT_CONFIG(shortcut)
        park_8->setCheckable(false);
        park_9 = new QPushButton(centralwidget);
        park_9->setObjectName("park_9");
        park_9->setEnabled(false);
        park_9->setGeometry(QRect(460, 330, 141, 41));
        park_9->setFont(font5);
        park_9->setText(QString::fromUtf8(""));
#if QT_CONFIG(shortcut)
        park_9->setShortcut(QString::fromUtf8(""));
#endif // QT_CONFIG(shortcut)
        park_9->setCheckable(false);
        park_10 = new QPushButton(centralwidget);
        park_10->setObjectName("park_10");
        park_10->setEnabled(false);
        park_10->setGeometry(QRect(460, 370, 141, 41));
        park_10->setFont(font5);
        park_10->setText(QString::fromUtf8(""));
#if QT_CONFIG(shortcut)
        park_10->setShortcut(QString::fromUtf8(""));
#endif // QT_CONFIG(shortcut)
        park_10->setCheckable(false);
        queue_2 = new QPushButton(centralwidget);
        queue_2->setObjectName("queue_2");
        queue_2->setEnabled(false);
        queue_2->setGeometry(QRect(290, 50, 141, 41));
        queue_2->setFont(font5);
        queue_3 = new QPushButton(centralwidget);
        queue_3->setObjectName("queue_3");
        queue_3->setEnabled(false);
        queue_3->setGeometry(QRect(290, 90, 141, 41));
        queue_3->setFont(font5);
        queue_4 = new QPushButton(centralwidget);
        queue_4->setObjectName("queue_4");
        queue_4->setEnabled(false);
        queue_4->setGeometry(QRect(290, 130, 141, 41));
        queue_4->setFont(font5);
        queue_5 = new QPushButton(centralwidget);
        queue_5->setObjectName("queue_5");
        queue_5->setEnabled(false);
        queue_5->setGeometry(QRect(290, 170, 141, 41));
        queue_5->setFont(font5);
        queue_6 = new QPushButton(centralwidget);
        queue_6->setObjectName("queue_6");
        queue_6->setEnabled(false);
        queue_6->setGeometry(QRect(290, 210, 141, 41));
        queue_6->setFont(font5);
        queue_7 = new QPushButton(centralwidget);
        queue_7->setObjectName("queue_7");
        queue_7->setEnabled(false);
        queue_7->setGeometry(QRect(290, 250, 141, 41));
        queue_7->setFont(font5);
        queue_8 = new QPushButton(centralwidget);
        queue_8->setObjectName("queue_8");
        queue_8->setEnabled(false);
        queue_8->setGeometry(QRect(290, 290, 141, 41));
        queue_8->setFont(font5);
        queue_9 = new QPushButton(centralwidget);
        queue_9->setObjectName("queue_9");
        queue_9->setEnabled(false);
        queue_9->setGeometry(QRect(290, 330, 141, 41));
        queue_9->setFont(font5);
        queue_10 = new QPushButton(centralwidget);
        queue_10->setObjectName("queue_10");
        queue_10->setEnabled(false);
        queue_10->setGeometry(QRect(290, 370, 141, 41));
        queue_10->setFont(font5);
        out = new QPushButton(centralwidget);
        out->setObjectName("out");
        out->setGeometry(QRect(10, 190, 251, 51));
        out->setFont(font3);
        log = new QTextEdit(centralwidget);
        log->setObjectName("log");
        log->setGeometry(QRect(20, 260, 231, 221));
#if QT_CONFIG(tooltip)
        log->setToolTip(QString::fromUtf8(""));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(statustip)
        log->setStatusTip(QString::fromUtf8(""));
#endif // QT_CONFIG(statustip)
#if QT_CONFIG(whatsthis)
        log->setWhatsThis(QString::fromUtf8(""));
#endif // QT_CONFIG(whatsthis)
#if QT_CONFIG(accessibility)
        log->setAccessibleName(QString::fromUtf8(""));
#endif // QT_CONFIG(accessibility)
#if QT_CONFIG(accessibility)
        log->setAccessibleDescription(QString::fromUtf8(""));
#endif // QT_CONFIG(accessibility)
        log->setDocumentTitle(QString::fromUtf8(""));
        log->setAcceptRichText(true);
        log->setTextInteractionFlags(Qt::TextInteractionFlag::TextSelectableByKeyboard|Qt::TextInteractionFlag::TextSelectableByMouse);
        log->setPlaceholderText(QString::fromUtf8(""));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 840, 22));
        menu = new QMenu(menubar);
        menu->setObjectName("menu");
        m = new QMenu(menubar);
        m->setObjectName("m");
        menuFile = new QMenu(menubar);
        menuFile->setObjectName("menuFile");
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menuFile->menuAction());
        menubar->addAction(menu->menuAction());
        menubar->addAction(m->menuAction());
        menu->addSeparator();
        menu->addSeparator();
        m->addAction(action);

        retranslateUi(MainWindow);

        park_1->setDefault(false);
        park_2->setDefault(false);
        park_3->setDefault(false);
        park_4->setDefault(false);
        park_5->setDefault(false);
        park_6->setDefault(false);
        park_7->setDefault(false);
        park_8->setDefault(false);
        park_9->setDefault(false);
        park_10->setDefault(false);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        action->setText(QString());
        parkButton->setText(QCoreApplication::translate("MainWindow", "\345\201\234\350\275\246", nullptr));
        randomButton->setText(QCoreApplication::translate("MainWindow", "\351\232\217\346\234\272\350\275\246\347\211\214", nullptr));
        queue_1->setText(QString());
        label->setText(QCoreApplication::translate("MainWindow", "\345\200\231\350\275\246\345\234\272", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\345\201\234\350\275\246\345\234\272", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "\344\276\277\351\201\223", nullptr));
        queue_2->setText(QString());
        queue_3->setText(QString());
        queue_4->setText(QString());
        queue_5->setText(QString());
        queue_6->setText(QString());
        queue_7->setText(QString());
        queue_8->setText(QString());
        queue_9->setText(QString());
        queue_10->setText(QString());
        out->setText(QCoreApplication::translate("MainWindow", "\345\207\272\350\275\246", nullptr));
        menu->setTitle(QString());
        m->setTitle(QString());
        menuFile->setTitle(QCoreApplication::translate("MainWindow", "\346\226\207\344\273\266", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
